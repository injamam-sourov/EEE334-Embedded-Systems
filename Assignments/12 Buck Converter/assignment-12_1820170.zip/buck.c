#include <16F877A.h>                      // include the PIC16F877A library
#device  adc=10                           // setting the adc at 10 bit
#include <math.h>                         // including the library for the math operation
#fuses   HS,NOWDT                         // setting Cristal Clock, No watch dog timer and No low voltage protection
#use     delay(clock=20000000)            // set the internal clock as 0MHz
  

int16 k;

void main()
{
 setup_adc_ports( ALL_ANALOG ); 
 setup_adc(ADC_CLOCK_INTERNAL);
 
 setup_timer_2(T2_DIV_BY_1,255,1);    // 20MHz clock, prescaler=4 formula: period = (20*1000)/(4*4*1*5)= 5kHz
 
 setup_ccp2(CCP_PWM);
  
 while(1)
  {
  set_adc_channel(0);
  delay_us(100);
  k = read_adc();
  set_pwm2_duty(k);
  }
   
}
