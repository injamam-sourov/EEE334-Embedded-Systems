#include <16F877A.h>
#fuses   HS,NOWDT
#use     delay(clock=4000000)

int sevenseg(int x);

void main()
{
 int v1,v2, v3,a, b, c; // declaring four variables

 while (1)              //starting an infinite loop
 {     
  v3=0;                 //setting the value of v2 to 0
  while (v3<2)         //limiting the value of v2 to less then 10 (0 to 9)
  {
   c=sevenseg(v3);     //calling the sevenseg function and storing the return value into a
   output_D(c);        //displaying the value stored in a via port C
   v3++;               //after displaying increment v2 by 1

   v2=0;              //setting the value of v2 to 0
   while (v2<8 || (v2<10 && v3==1) )      //limiting the value of v2 to less then 10 (0 to 9)
   {
    b=sevenseg(v2);   //calling the sevenseg function and storing the return value into a
    output_C(b);      //displaying the value stored in a via port C
    v2++;             //after displaying increment v2 by 1
   
    v1=0;             //setting the value of v1 to 0
    while (v1<10)     //limiting the value of v1 to less then 10 (0 to 9)
    {
     
    if(v3==2 && v2==8 && v1==1) break;
    
     
     a=sevenseg(v1);  //calling the sevenseg function and storing the return value into b
     output_B(a);     //displaying the value stored in a via port B         
     
     // increment only after input is high then low
     while (input_state(pin_A0)==1);
     while (input_state(pin_A0)==0);
     
     v1++;            // after displaying increment v1 by 1; v1=v1+1;

    }                 //3rd while loof end    v1=1; a=6;  output_b(6);  display=9
   }                  //2nd while loof end    v2=9; b=63; output_c(6);  display=1
  }
 }                   //1st while loof end
}


int sevenseg(int x)   //sevenseg function   v1=0; a=63, v1=1; a=6; 
{
 if (x==0){return 63;}
 if (x==1){return 6;}
 if (x==2){return 91;}
 if (x==3){return 79;}
 if (x==4){return 102;}
 if (x==5){return 109;}
 if (x==6){return 125;}
 if (x==7){return 7;}
 if (x==8){return 127;}
 if (x==9){return 111;}
}



