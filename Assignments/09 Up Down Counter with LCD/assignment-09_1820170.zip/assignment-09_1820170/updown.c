#include <16F877.h>                                                            // include the PIC16F877A library
#device  adc=10                                                                // setting the adc at 10 bit
#include <math.h>                                                              // including the library for the math operation
#fuses   XT,NOWDT,NOLVP                                                        // setting Cristal Clock, No watch dog timer and No low voltage protection
#use     delay(clock=4000000)                                                  // set the internal clock as 4MHz

#include "lcd_setup.c"


void main()
{
 int counter=0;
 lcd_init();   
 
 while(1)
 {
  if(input(PIN_B0)==1)
  {
   counter++;
  }
  
  while(input(PIN_B0)==1)
  {
  
  }
  
  
  if(input(PIN_B1)==1)
  {
   counter=counter-1;
  }
      
  while(input(PIN_B1)==1)
  {
  
  }
    
      lcd_gotoxy(1,1);                                                         
      printf(LCD_PUTC,"Counter:");                        
      lcd_gotoxy(1,2);                                                         
      printf(LCD_PUTC,"%d ", counter);                              
       
 }
}

