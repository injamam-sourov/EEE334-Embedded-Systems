#include <16F877A.h>                      // include the PIC16F877A library
#device  adc=10                         // setting the adc at 10 bit
#include <math.h>                        // including the library for the math operation
#fuses   HS,NOWDT                        // setting Cristal Clock, No watch dog timer and No low voltage protection
#use     delay(clock=20000000)           // set the internal clock as 40MHz

 int16 a;

 void main()
 {
  setup_adc_ports( ALL_ANALOG ); 
  setup_adc(ADC_CLOCK_INTERNAL);
  
  setup_timer_2(T2_DIV_BY_4,255,1);     // 20MHz clock, prescaler=4, resolution=4 *256=1024. formula: (20*1000)/(4*4*256)= 5khz pwm frequency
  setup_ccp1(CCP_PWM);
  
  while(1)
  {
   set_adc_channel(0);
   a = read_adc();
   set_pwm1_duty(a);
  }
 }

