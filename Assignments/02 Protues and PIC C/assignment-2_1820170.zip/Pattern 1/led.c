#include <16F877A.h>
#fuses HS, NOWDT
#use delay(clock= 4000000)



void main()
{
   while(true)
   {
      output_high(PIN_B0);
      output_high(PIN_B1);
      output_high(PIN_B4);
      output_high(PIN_C4);
      output_high(PIN_D0);
      output_high(PIN_D1);
      output_high(PIN_D4);      
      
      delay_ms(1000);
      
      output_low(PIN_B0);
      output_low(PIN_B1);
      output_low(PIN_B4);
      output_low(PIN_C4);
      output_low(PIN_D0);
      output_low(PIN_D1);
      output_low(PIN_D4);
      
      delay_ms(1000);
   }

}
