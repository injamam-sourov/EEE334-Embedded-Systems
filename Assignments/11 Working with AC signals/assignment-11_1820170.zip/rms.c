#include <16F877.h>                                                            // include the PIC16F877A library
#device  adc=10                                                                // setting the adc at 10 bit
#include <math.h>                                                              // including the library for the math operation
#fuses   XT,NOWDT,NOLVP                                                        // setting Cristal Clock, No watch dog timer and No low voltage protection
#use     delay(clock=40000000)                                                  // set the internal clock as 4MHz
#include "lcd_setup.c"


float vrms, irms, adc0, adc1;
float v0, c, isquare, sum_i=0, sum_isquare=0;
float v1, v, vsquare, sum_v=0, sum_vsquare=0;

int i;
void main() {
  
  lcd_init();
  setup_adc_ports( ALL_ANALOG );
  setup_adc(ADC_CLOCK_INTERNAL );

  while(1)
  {
    i=0;
    sum_v = 0; sum_vsquare = 0;
    sum_i = 0; sum_isquare = 0;
    
    while(input(PIN_D0)==1){     // in between zero crossings of rectified wave
       
       // current sensor output AN0
       set_adc_channel(0);
       adc0 = read_adc(); 
       v0 = adc0/204.6;
       c = (v0-2.5)/0.185;    // current sensor offset voltage = 2.5V, sensitivity 0.185V/A
       // compute c1^2+c2^2+c3^2...+cn^2
       isquare = c*c;
       sum_isquare = sum_isquare + isquare;
       
       set_adc_channel(1);
       adc1 = read_adc(); 
       v1 = adc1/204.6;
       v = v1*62.4*1.18;      // transform ratio, additional calibration
       // compute v1^2+v2^2+v3^2...+cn^2
       vsquare = v*v;
       sum_vsquare = sum_vsquare + vsquare;
       
       
       i++;
       delay_ms(10); 
    }
    
    // compute rms values
    vrms = sqrt(sum_vsquare/i);
    irms = sqrt(sum_isquare/i);
    
        
    lcd_gotoxy(1,1);                                                         
    printf(LCD_PUTC,"Vrms: %.2f V", vrms );                        
    lcd_gotoxy(1,2);                                                         
    printf(LCD_PUTC,"Irms: %.2f A", irms );      
    delay_ms(275);
  }
}


