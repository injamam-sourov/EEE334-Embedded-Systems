#include <16F877A.h>                                                           
#device  adc=10                                                                
#include <math.h>                                                              
#fuses   XT,NOWDT,NOLVP                                                        
#use     delay(clock=71680000)  


void main()
{
 setup_timer_2(T2_DIV_BY_1,255,1);    // 20MHz clock, prescaler=1, resolution=4 *256=1024. formula: (71.68*1000)/(4*1*256)=70.4khz pwm frequency
 
 setup_ccp2(CCP_PWM);
  
 set_pwm2_duty(512);
   
}

