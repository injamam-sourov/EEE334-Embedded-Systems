#include <16F877.h>                                                            // include the PIC16F877A library
#device  adc=10                                                                // setting the adc at 10 bit
#include <math.h>                                                              // including the library for the math operation
#fuses   XT,NOWDT,NOLVP                                                        // setting Cristal Clock, No watch dog timer and No low voltage protection
#use     delay(clock=4000000)                                                  // set the internal clock as 4MHz

#include "lcd_setup.c"

void main()
{
 lcd_init();   
 
 while(1)
 {
  
  lcd_gotoxy(1,1);
  printf(LCD_PUTC,"Injamamul Haque "); 
  
  lcd_gotoxy(1,2);
  printf(LCD_PUTC,"ID: 1820170");
  
  
  delay_ms(4000);
  lcd_gotoxy(1,1);
  printf(LCD_PUTC,"njamamul Haque S");
  delay_ms(1000);
  lcd_gotoxy(1,1);
  printf(LCD_PUTC,"jamamul Haque So");
  delay_ms(1000);
  lcd_gotoxy(1,1);
  printf(LCD_PUTC,"amamul Haque Sou");
  delay_ms(1000);
  lcd_gotoxy(1,1);
  printf(LCD_PUTC,"mamul Haque Sour");
  delay_ms(1000);
  lcd_gotoxy(1,1);
  printf(LCD_PUTC,"amul Haque Souro");
  delay_ms(1000);
  lcd_gotoxy(1,1);
  printf(LCD_PUTC,"mul Haque Sourov");
   
  delay_ms(5000);
  
  lcd_clear();
  delay_ms(2000);

  }
}

