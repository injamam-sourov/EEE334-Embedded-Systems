#include <16F877.h>                                                            // include the PIC16F877A library
#device  adc=10                                                                // setting the adc at 10 bit
#include <math.h>                                                              // including the library for the math operation
#fuses   XT,NOWDT,NOLVP                                                        // setting Cristal Clock, No watch dog timer and No low voltage protection
#use     delay(clock=4000000)                                                  // set the internal clock as 4MHz
#include "lcd_setup.c"

/*
// map linearly related variables 
float map(float x, float in_min, float in_max, float out_min, float out_max) {
  return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}
*/



/*
LDR PARAMETERS:
(1) Resistance at 1 lux = 100 Ohm (set in Proteus)
(2) General Formula: R = k * [LUX/10]^(-0.85)
(3) Finding k from (1): k = 14.12
*/

double k = 14.12, adc=0, v=0, r=0, l=0;

void main() {
  lcd_init();

  setup_adc_ports( ALL_ANALOG );
  setup_adc(ADC_CLOCK_INTERNAL );

  while(1)
  {
     
    set_adc_channel(0);
    adc = read_adc();
    
/* non linear relation hence didnt work
    // directly maping voltage
    l = map(adc,0.421859,0.0481912,0.1,15.1);
*/    
    // input pin/LDR voltage (convert from 10 bit adc value)
    v = adc/204.6;

    // LDR resistance from voltage divider: v_ldr = [r_ldr/(1+r_ldr)]*5
    r = 1000/((5.0/v)-1);   
    
    // (most accurate) from general formula (2)
    l = 10*pow(r/k,-1.176470588);
    
    // (doesnt work) using formula derived from hardware plot
    // l = 12500000*pow(r,-1.4059);
        
    lcd_gotoxy(1,1);                                                         
    printf(LCD_PUTC,"Light Intensity:" );                        
    lcd_gotoxy(1,2);                                                         
    printf(LCD_PUTC,"%.2f LUX", l );                              
         
    delay_ms(1000);
  }
}


